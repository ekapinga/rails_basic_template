class Roles::Developer < ActiveRecord::Base
end
