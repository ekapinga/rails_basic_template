class Roles::Admin < ActiveRecord::Base
end
